@echo off
python -m pip install customtkinter
pause
