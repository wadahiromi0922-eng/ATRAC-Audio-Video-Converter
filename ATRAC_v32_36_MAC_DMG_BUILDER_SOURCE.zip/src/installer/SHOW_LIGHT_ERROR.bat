@echo off
setlocal
cd /d "%~dp0"
if not exist "light.log" (
  echo light.log not found.
  pause
  exit /b 1
)
powershell.exe -NoProfile -Command "$x=Get-Content -LiteralPath '%~dp0light.log'; Write-Host '===== LIGHT ERRORS ====='; $x | Where-Object { $_ -match 'error LGHT|error ' }; Write-Host ''; Write-Host '===== LAST 60 LINES ====='; $x | Select-Object -Last 60"
pause
endlocal
