﻿ATRAC v31.16 MSI インストーラー

使い方
1. installer フォルダーの BUILD_MSI_INSTALLER.bat をダブルクリック。
2. EXE が無ければ自動で先に EXE をビルドします。
3. WiX Toolset 3.14 が無ければ公式 GitHub リリースから自動取得します。
4. 完成した MSI:
   Release\ATRAC_Audio_Converter_v31_16_Setup.msi

インストーラーの追加機能
- インストール前:
  「デスクトップにショートカットを作成する」
  チェックボックス（初期状態ON）

- インストール完了後:
  「インストール完了後にアプリを起動する」
  チェックボックス（初期状態ON）

インストール先
- ユーザーごとの LocalAppData\Programs\ATRAC対応 オーディオ・ビデオコンバーター
- 管理者権限を要求しない per-user MSI にしています。

注意
- Windows 上での実際の MSI 実行テストはこの環境では行っていません。


v31.16: CancelDlg link added. light.exe culture forcing removed. candle/light logs are saved for troubleshooting.


v31.16: Removed duplicate BrowseDlg OK events already provided by WixUIExtension.


v31.16: Removed duplicate ExitDialog Finish/EndDialog publish. BrowseDlg duplicate publishes remain removed.


v31.16: Japanese MSI database code page set to Windows-932 (Shift-JIS) using Product Codepage and Package SummaryCodepage.


v31.16: Added explicit ATRAC_ja-jp.wxl with Codepage=932 and Light now links with -cultures:ja-jp -loc ATRAC_ja-jp.wxl, avoiding the en-US/1252 fallback.


v31.18: Fixed WiX CNDL0230 by assigning AppComponent a stable explicit GUID because it contains both a file and an HKCU registry KeyPath.
