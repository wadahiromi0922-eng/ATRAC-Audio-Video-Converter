@echo off
setlocal
cd /d "%~dp0"

echo.
echo ATRAC v31.38 MSI installer builder
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_MSI_INSTALLER.ps1"
if errorlevel 1 (
  echo.
  echo MSI build failed.
  pause
  exit /b 1
)

echo.
echo MSI build finished.
echo Check the Release folder.
pause
endlocal
