﻿$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$root = Split-Path $PSScriptRoot -Parent
$exe = Join-Path $root "Release\ATRAC_Audio_Converter_v31_38_Unified.exe"

Write-Host ""
Write-Host "=== ATRAC v31.38 MSI Builder ===" -ForegroundColor Cyan

if (!(Test-Path $exe)) {
    Write-Host "EXE not found. Building EXE first..." -ForegroundColor Yellow
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "AUTO_BUILD_V30.ps1")
    if ($LASTEXITCODE -ne 0) { throw "EXE build failed." }
}

if (!(Test-Path $exe)) {
    throw "Release\ATRAC_Audio_Converter_v31_38_Unified.exe was not found."
}

$tools = Join-Path $root "tools"
$wixDir = Join-Path $tools "wix314"
$zip = Join-Path $tools "wix314-binaries.zip"
$candle = Join-Path $wixDir "candle.exe"
$light = Join-Path $wixDir "light.exe"

New-Item -ItemType Directory -Force -Path $tools | Out-Null

if (!(Test-Path $candle) -or !(Test-Path $light)) {
    Write-Host "Downloading WiX Toolset 3.14..." -ForegroundColor Yellow
    $url = "https://github.com/wixtoolset/wix3/releases/download/wix314rtm/wix314-binaries.zip"
    Invoke-WebRequest -Uri $url -OutFile $zip
    if (Test-Path $wixDir) { Remove-Item $wixDir -Recurse -Force }
    Expand-Archive -Path $zip -DestinationPath $wixDir -Force
}

$outDir = Join-Path $root "Release"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$obj = Join-Path $PSScriptRoot "ATRAC_Setup.wixobj"
$msi = Join-Path $outDir "ATRAC_Audio_Video_Converter_v31_38_Setup.msi"
$wxs = Join-Path $PSScriptRoot "ATRAC_Setup.wxs"
$uiExt = Join-Path $wixDir "WixUIExtension.dll"
$loc = Join-Path $PSScriptRoot "ATRAC_ja-jp.wxl"
$candleLog = Join-Path $PSScriptRoot "candle.log"
$lightLog = Join-Path $PSScriptRoot "light.log"

Remove-Item $obj,$msi,$candleLog,$lightLog -Force -ErrorAction SilentlyContinue

Write-Host "Compiling MSI source..." -ForegroundColor Cyan
& $candle -nologo -arch x64 "-dAppExe=$exe" $wxs -out $obj 2>&1 | Tee-Object -FilePath $candleLog
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "CANDLE ERROR:" -ForegroundColor Red
    Get-Content $candleLog | Select-Object -Last 30
    throw "candle.exe failed."
}

Write-Host "Linking MSI..." -ForegroundColor Cyan

# Do not force a UI culture here. The Japanese text written directly in the
# WXS file remains Japanese, while this avoids failures caused by a missing
# WiX localization payload.
& $light -nologo -ext $uiExt -cultures:ja-jp -loc $loc $obj -out $msi 2>&1 | Tee-Object -FilePath $lightLog
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "LIGHT ERROR (last lines):" -ForegroundColor Red
    Get-Content $lightLog | Select-Object -Last 40
    Write-Host ""
    Write-Host "Full log:" -ForegroundColor Yellow
    Write-Host $lightLog
    throw "light.exe failed."
}

Write-Host ""
Write-Host "Done:" -ForegroundColor Green
Write-Host $msi -ForegroundColor Green
