@echo off
setlocal
cd /d "%~dp0"
call "%~dp0installer\BUILD_MSI_INSTALLER.bat"
endlocal
