﻿使い方

1. ZIPを「すべて展開」
2. BUILD_EXE_ONE_CLICK.bat をダブルクリック
3. 自動で必要ファイルを取得
   - ffmpeg.exe
   - ffprobe.exe
   - ffplay.exe
   - atracdenc.exe
4. Python用パッケージも自動で準備
5. Release\ATRAC_Audio_Converter_Tag_Editor.exe が完成

※ 初回ビルド時はインターネット接続が必要です。
※ FFmpeg Windows build はFFmpeg公式ダウンロードページから案内されている
   gyan.dev の essentials build を使用します。
※ atracdenc は dcherednik/atracdenc の公式GitHub Releasesから取得します。


修正: 電卓ページがナビゲーションに確実に表示されるよう修正済み。


v19: 変換先に MKV(H.264/AAC), WEBM(VP9/Opus), MOV(H.264/AAC) を追加。

v20 修正:
- 変換ページのドラッグ＆ドロップを実際のファイル一覧(self.listbox)へ接続
- タグ編集のドラッグ＆ドロップで誤った変数名を修正
- PyInstallerに tkinterdnd2 のTkDND本体を --collect-all で同梱
- 一括タグ編集を980x720・リサイズ可能に変更
- トラック番号入力を画面最上部へ移動して常に見えるように変更
- 一括編集フォームを2列化し、小さい画面でも操作しやすく変更
- 一括編集ファイル一覧へ直接ドラッグ＆ドロップ可能


v21: 電卓ボタンを実際のサイドバーナビゲーションへ追加し、電卓ページへのルーティングを修正。

v22:
- 実際のサイドバー navs 配列に「電卓」を直接追加
- 実際の show_page() に calculator ルートを直接追加
- 日本語/英語の電卓表示名を追加
- 電卓ページ本体の存在をビルド前に検証済み

v23:
- オンラインDL画面でTikTok対応を明示
- TikTok URLは既存のyt-dlpバックエンドで処理
- 自分の投稿、または保存許可のある動画向け
- YouTubeの既存機能、一括DL、画質/音質設定は維持

v24:
- 「オンラインDL」を廃止
- 左メニューに「YouTubeダウンロード」「TikTokダウンロード」を別々に追加
- YouTube画面はYouTube URLのみ、TikTok画面はTikTok URLのみ受付
- 一括DL・画質/音質・進捗表示は両方でそのまま利用

v25 CD Edition:
- 左メニューに「CD」を追加
- CD/DVDドライブ検出
- 音楽CD取り込み画面（WAV / MP3 / FLAC）
- CD書き込み用の音楽フォルダをWindowsのディスク書き込み機能へ渡せる
- アプリ表示名: ATRACオーディオコンバーターtag編集ソフト v25
注意: 音楽CDの直接取り込みは、同梱FFmpegビルドがCDDA/libcdio入力に対応している場合のみ動作します。

高速ビルド:
- 初回だけ BUILD_EXE_ONE_CLICK.bat を実行してください。
- 2回目以降は FAST_REBUILD.bat を使用できます。
- 通常ビルドも、既にあるPythonパッケージとFFmpeg類は再ダウンロードしません。
- PyInstallerのキャッシュを残すため、再ビルドが以前より速くなります。

v26 Format Tool:
- 左メニューに「フォーマット」を追加
- USBメモリ / SDカードなど「リムーバブルドライブ」だけを表示
- システムドライブは対象外
- FAT32 / exFAT / NTFS
- ボリューム名設定
- 実行前に FORMAT の入力 + 最終確認
- Windows標準 format.com を使用
- 32GB超のFAT32はWindows標準制限のためブロック
\n\nv27 changes:\n- FORMAT typing removed; final Yes/No warning remains.\n- Removed 32 GB size block.\n- FAT32 uses Windows PowerShell Format-Volume attempt; actual large-FAT32 support depends on Windows.\n- CD page label changed from Format to Output.\n- System drive protection/removable-drive-only checks remain.\n

v28:
- 角丸カード / 角丸ボタンのモダンUI (CustomTkinter)
- 動画編集: トリミング / 回転 / ミュート
- Windows画面録画: gdigrab、FPS選択、DirectShow音声デバイス選択
- 動画圧縮: CRF / 解像度選択
- DVD作成: DVD互換MPEG-2作成。dvdauthor.exeがあればVIDEO_TSも作成


v29:
- 画像編集を追加: 回転 / 反転 / 明るさ / コントラスト / 彩度 / リサイズ / 文字入れ
- Windowsにインストール済みのフォント一覧を選択可能（フォントファイルは同梱しません）
- 拡張子変換を追加: 多数の動画・音声・画像形式
- MP4/MKV/WEBM/MOV/AVI、MP3/WAV/FLAC/M4A/AAC/OGG/OPUS、PNG/JPEG/WEBP/BMP/TIFF/GIF
- 既存の角丸UIを維持


v30:
- ICOを画像編集の出力形式に追加
- ICOを万能拡張子変換の出力形式に追加
- PNG/JPG/JPEG/WEBP/BMP/TIFF/GIF/ICO -> ICO
- ICO -> PNG/JPG等にも対応
- ICO出力は 16/24/32/48/64/128/256px のマルチサイズWindowsアイコン

v30.3:
- Light/Darkと日本語/Englishを上部バーにも配置し、常に押せるよう修正
- テーマと言語変更後も現在ページを維持
- CustomTkinterのappearance modeも同期
- 画面録画を改修: gdigrab起動確認、FFmpegエラー表示、録画状態確認、停止/保存処理を改善
- 録画が失敗した場合に原因を隠さず表示

v30.4 HARD FIX:
- LIGHT/DARK と ENGLISH/日本語をサイドバー上部とトップバーに常時表示
- 設定ボタンは CustomTkinter ではなく通常の Tk Button に変更
- 画面録画の開始/停止ボタンも通常の Tk Button に変更
- 録画ボタンを押した瞬間に状態表示を更新
- DirectShow音声機器検索を自動実行しないよう変更（手動・バックグラウンド検索）
- FFmpeg存在確認を強化
- gdigrabに画面サイズを明示
- EXE名を ATRAC_Audio_Converter_v30_4.exe に変更し、旧EXEとの取り違えを防止
- TEST_APP_DIRECT.bat を追加

v30.5:
- 画面録画開始処理を完全にバックグラウンド化
- Tk画面が固まらないよう修正
- 録画開始準備中 -> 録画開始を確認中 -> ● 録画中 の状態表示
- 開始失敗時は例外とFFmpegログ末尾を必ずダイアログ表示
- gdigrabコマンドをより単純な構成に戻して互換性を改善


v31.38:
- TikTok downloader: yt-dlp extractor modules are fully collected by PyInstaller.
- TikTok MP4 uses a TikTok-friendly format fallback and browser-like headers.
- Build scripts update yt-dlp before creating the EXE.

v31.39:
- Spotifyダウンロード機能を追加（サイドバー / ホーム画面）
- SpotSaver.net と同様の考え方: Spotify本体からは音声を取得せず、公開ソースからマッチする音声を保存
- 曲・アルバム・プレイリスト・ポッドキャストURL対応
- デフォルト出力: MP3 320kbps + メタデータ/サムネイル埋め込み
- 既存のYouTube / TikTokダウンロードと同じ操作感

