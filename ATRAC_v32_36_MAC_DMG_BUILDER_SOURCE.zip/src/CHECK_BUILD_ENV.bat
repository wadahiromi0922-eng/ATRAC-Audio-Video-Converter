@echo off
echo ==========================================
echo ATRAC v30 - Build Environment Check
echo ==========================================
python --version
python -c "import PyInstaller; print('PyInstaller OK')"
python -c "import yt_dlp; print('yt-dlp OK')"
python -c "import tkinterdnd2; print('tkinterdnd2 OK')"
python -c "import customtkinter; print('customtkinter OK')"
python -c "from PIL import Image; print('Pillow OK')"
echo.
pause
