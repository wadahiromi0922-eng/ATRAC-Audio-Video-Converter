@echo off
cd /d "%~dp0"
python ATRAC_UI_v31_20_UNIFIED.pyw
pause
