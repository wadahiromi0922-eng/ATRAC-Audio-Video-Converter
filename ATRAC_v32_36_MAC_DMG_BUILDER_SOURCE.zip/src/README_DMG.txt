ATRAC v32.36 macOS DMG版
========================

MacでDMGを作る方法
------------------
1. このZIPをMacで展開
2. BUILD_DMG.command を右クリック →「開く」
3. Homebrewが未導入ならHomebrewを導入して再実行
4. ビルドが終わると次の2つができます

   Release_mac/ATRAC Audio Converter Tag Editor.app
   Release_mac/ATRAC_v32.36_macOS.dmg

DMGの使い方
------------
DMGを開くと
- ATRAC Audio Converter Tag Editor.app
- Applications
が表示されます。
ATRACアプリをApplicationsへドラッグしてください。

注意
----
- DMGはmacOS標準の hdiutil で作成します。
- .app / .dmg はmacOS上でのみビルドできます。
- Apple Silicon / Intel Mac の両方で、そのMac自身のCPU向けにビルドします。
- 初回ビルド時はHomebrew/Pythonパッケージ/yt-dlp/atracdenc取得のためネット接続が必要です。
- Developer ID署名・公証(notarization)は行っていないため、初回起動でmacOSに止められた場合は右クリック→開くを使ってください。
