ATRAC v32.22 macOS版
====================

このZIPは v32.21 の機能を残したまま macOS対応を追加したソース版です。

Macでのビルド方法
-----------------
1. ZIPを展開
2. BUILD_MAC.command を右クリック →「開く」
3. Homebrew が未導入なら先にHomebrewを導入して、もう一度 BUILD_MAC.command を実行
4. 完了すると Release_mac/ATRAC Audio Converter Tag Editor.app ができます

対応したmacOS部分
-----------------
- Apple Silicon / Intel Mac の両方で、そのMac上でネイティブビルド
- FFmpeg / ffprobe / ffplay
- YouTube / TikTok DL 用 yt-dlp + Deno
- 動画・音声・画像変換
- 動画・音声・画像圧縮
- フォルダD&D / 一括圧縮 / 同名ファイルのフォルダ分け
- 圧縮後も元のファイル名を維持
- タグ編集 / 一括タグ編集
- 画像編集で macOS のフォント検索に対応
- Carrozzeria AT3変換用 atracdenc をMac上で自動ビルド
- USB / SDフォーマットは macOS diskutil を使用
- CD検出・取り込み・書き込みは macOS drutil + cd-paranoia を使用
- PDF機能

注意
----
- Windows専用APIを使う処理はmacOSではmacOS用処理へ分岐します。
- Mac版の .app はWindows/Linux上では作れません。BUILD_MAC.commandをMac本体で実行してください。
- 初回はHomebrewパッケージ、Pythonパッケージ、yt-dlp、atracdencソースを取得するためインターネット接続が必要です。
- macOSのセキュリティで初回起動が止められた場合は、アプリを右クリック →「開く」を使用してください。
- USB/SDフォーマットはデータを消去します。アプリ側で外付け物理ディスクだけを対象にし、内蔵ディスクはブロックします。
