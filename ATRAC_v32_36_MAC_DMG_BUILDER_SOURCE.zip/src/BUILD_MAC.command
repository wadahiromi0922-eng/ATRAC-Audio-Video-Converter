#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

APP_NAME="ATRAC Audio Converter Tag Editor"
VENV=".venv-mac"
PY_SRC="ATRAC_UI_v31_38_UNIFIED.pyw"

echo "=============================================="
echo " ATRAC v32.22 macOS BUILD"
echo " Apple Silicon / Intel Mac"
echo "=============================================="

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This builder must be run on macOS."
  read -r -p "Press Enter to close..." _
  exit 1
fi

if ! command -v brew >/dev/null 2>&1; then
  echo ""
  echo "Homebrew が必要です。"
  echo "Homebrew をインストールしてから、この BUILD_MAC.command をもう一度実行してください。"
  echo ""
  read -r -p "Press Enter to close..." _
  exit 1
fi

# Make Homebrew visible even when the .command file is opened from Finder.
if [[ -d /opt/homebrew/bin ]]; then export PATH="/opt/homebrew/bin:$PATH"; fi
if [[ -d /usr/local/bin ]]; then export PATH="/usr/local/bin:$PATH"; fi

echo "[1/5] Installing/updating macOS tools..."
brew list python >/dev/null 2>&1 || brew install python
brew list ffmpeg >/dev/null 2>&1 || brew install ffmpeg
brew list deno >/dev/null 2>&1 || brew install deno
brew list cmake >/dev/null 2>&1 || brew install cmake
brew list libsndfile >/dev/null 2>&1 || brew install libsndfile
brew list pkgconf >/dev/null 2>&1 || brew install pkgconf
brew list git >/dev/null 2>&1 || brew install git
brew list googletest >/dev/null 2>&1 || brew install googletest
brew list libcdio-paranoia >/dev/null 2>&1 || brew install libcdio-paranoia
brew list dvdauthor >/dev/null 2>&1 || brew install dvdauthor

echo "[2/5] Preparing Python environment..."
PYTHON="$(command -v python3)"
"$PYTHON" -m venv "$VENV"
source "$VENV/bin/activate"
python -m pip install --upgrade pip wheel
python -m pip install --upgrade pyinstaller yt-dlp ytmusicapi tkinterdnd2 customtkinter Pillow mutagen

echo "[3/5] Getting current yt-dlp standalone macOS binary..."
mkdir -p mac_tools
YTDLP="$PWD/mac_tools/yt-dlp"
curl -L --fail --retry 3 \
  "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos" \
  -o "$YTDLP"
chmod +x "$YTDLP"

echo "[4/5] Building atracdenc for this Mac..."
ATRAC_BIN="$PWD/mac_tools/atracdenc"
if [[ ! -x "$ATRAC_BIN" ]]; then
  rm -rf _atracdenc_mac
  git clone --depth 1 --recursive https://github.com/dcherednik/atracdenc.git _atracdenc_mac
  cmake -S _atracdenc_mac -B _atracdenc_mac/build \
    -DCMAKE_BUILD_TYPE=Release \
    -DATRACDENC_PCM_IO_BACKEND=libsndfile
  cmake --build _atracdenc_mac/build --config Release -j "$(sysctl -n hw.ncpu)"
  cp _atracdenc_mac/build/src/atracdenc "$ATRAC_BIN"
  chmod +x "$ATRAC_BIN"
fi

echo "[5/5] Creating .app..."
rm -rf build dist Release_mac
mkdir -p Release_mac

FFMPEG="$(command -v ffmpeg)"
FFPROBE="$(command -v ffprobe)"
FFPLAY="$(command -v ffplay)"
DENO="$(command -v deno)"
CDP="$(command -v cd-paranoia || true)"
DVDAUTHOR="$(command -v dvdauthor || true)"

ARGS=(
  --noconfirm --clean --windowed --onedir
  --name "$APP_NAME"
  --icon "ATRAC_v30.icns"
  --hidden-import tkinterdnd2
  --hidden-import customtkinter
  --hidden-import ytmusicapi
  --collect-all tkinterdnd2
  --collect-all customtkinter
  --collect-all mutagen
  --collect-all ytmusicapi
  --add-binary "$FFMPEG:."
  --add-binary "$FFPROBE:."
  --add-binary "$FFPLAY:."
  --add-binary "$DENO:."
  --add-binary "$YTDLP:."
  --add-binary "$ATRAC_BIN:."
)
[[ -n "$CDP" ]] && ARGS+=(--add-binary "$CDP:.")
[[ -n "$DVDAUTHOR" ]] && ARGS+=(--add-binary "$DVDAUTHOR:.")

python -m PyInstaller "${ARGS[@]}" "$PY_SRC"
cp -R "dist/$APP_NAME.app" "Release_mac/$APP_NAME.app"

# Ad-hoc sign so Gatekeeper sees a consistent local bundle after PyInstaller edits.
codesign --force --deep --sign - "Release_mac/$APP_NAME.app" >/dev/null 2>&1 || true

echo ""
echo "=============================================="
echo " DONE"
echo " Release_mac/$APP_NAME.app"
echo "=============================================="
echo "初回起動で macOS が止めた場合:"
echo "アプリを右クリック → 開く → 開く"
read -r -p "Press Enter to close..." _
