﻿$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Get-Json($url) {
    Invoke-RestMethod -Headers @{"User-Agent"="ATRAC-Audio-Converter"} -Uri $url
}
function Download($url,$out) {
    python -m pip install --upgrade yt-dlp
Write-Host "Downloading $url"
    Invoke-WebRequest -Headers @{"User-Agent"="ATRAC-Audio-Converter"} -Uri $url -OutFile $out
}

Write-Host "=========================================="
Write-Host "ATRAC対応 オーディオ・ビデオコンバーター - ONE CLICK BUILD"
Write-Host "=========================================="

# 1) FFmpeg / ffprobe / ffplay
if (!(Test-Path ".\ffmpeg.exe") -or !(Test-Path ".\ffprobe.exe") -or !(Test-Path ".\ffplay.exe")) {
    Write-Host ""
    Write-Host "[1/3] Getting FFmpeg Windows build..."
    # gyan.dev is one of the Windows build providers linked from FFmpeg's official download page.
    $ffzip = Join-Path $PWD "ffmpeg-release-essentials.zip"
    Download "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip" $ffzip
    $tmp = Join-Path $PWD "_ffmpeg_tmp"
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    Expand-Archive $ffzip $tmp -Force
    foreach ($n in @("ffmpeg.exe","ffprobe.exe","ffplay.exe")) {
        $f = Get-ChildItem $tmp -Recurse -Filter $n | Select-Object -First 1
        if (!$f) { throw "$n was not found in FFmpeg package." }
        Copy-Item $f.FullName (Join-Path $PWD $n) -Force
    }
    Remove-Item $tmp -Recurse -Force
    Remove-Item $ffzip -Force
} else {
    Write-Host "[1/3] FFmpeg tools already present."
}

# 2) atracdenc
if (!(Test-Path ".\atracdenc.exe")) {
    Write-Host ""
    Write-Host "[2/3] Getting atracdenc..."
    $r = Get-Json "https://api.github.com/repos/dcherednik/atracdenc/releases/latest"
    $a = $r.assets | Where-Object {
        $_.name -match '(win|windows|msvc|mingw)' -and $_.name -match '\.(zip|exe)$'
    } | Select-Object -First 1
    if (!$a) {
        throw "No Windows atracdenc binary was found in the latest official release."
    }
    $dst = Join-Path $PWD $a.name
    Download $a.browser_download_url $dst
    if ($dst -match '\.zip$') {
        $tmp = Join-Path $PWD "_atracdenc_tmp"
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        Expand-Archive $dst $tmp -Force
        $e = Get-ChildItem $tmp -Recurse -Filter "atracdenc.exe" | Select-Object -First 1
        if (!$e) { throw "atracdenc.exe was not found in downloaded package." }
        Copy-Item $e.FullName (Join-Path $PWD "atracdenc.exe") -Force
        Remove-Item $tmp -Recurse -Force
        Remove-Item $dst -Force
    } else {
        Copy-Item $dst (Join-Path $PWD "atracdenc.exe") -Force
        if ($dst -ne (Join-Path $PWD "atracdenc.exe")) { Remove-Item $dst -Force }
    }
} else {
    Write-Host "[2/3] atracdenc already present."
}


# yt-dlp standalone executable (kept current at build time)
if (!(Test-Path ".\yt-dlp.exe")) {
    Write-Host ""
    Write-Host "Getting latest yt-dlp.exe..."
    Invoke-WebRequest -Headers @{"User-Agent"="ATRAC-Audio-Converter"} `
      -Uri "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" `
      -OutFile ".\yt-dlp.exe"
}

# Deno runtime for current YouTube EJS challenge solving
if (!(Test-Path ".\deno.exe")) {
    Write-Host ""
    Write-Host "Getting Deno runtime..."
    $denoZip = Join-Path $PWD "deno-x86_64-pc-windows-msvc.zip"
    Invoke-WebRequest -Headers @{"User-Agent"="ATRAC-Audio-Converter"} `
      -Uri "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip" `
      -OutFile $denoZip
    $denoTmp = Join-Path $PWD "_deno_tmp"
    if (Test-Path $denoTmp) { Remove-Item $denoTmp -Recurse -Force }
    Expand-Archive $denoZip $denoTmp -Force
    $denoExe = Get-ChildItem $denoTmp -Recurse -Filter "deno.exe" | Select-Object -First 1
    if (!$denoExe) { throw "deno.exe was not found." }
    Copy-Item $denoExe.FullName ".\deno.exe" -Force
    Remove-Item $denoTmp -Recurse -Force
    Remove-Item $denoZip -Force
}

# 3) Build
Write-Host ""
Write-Host "[3/3] Installing Python build packages and creating EXE..."
python --version
if ($LASTEXITCODE -ne 0) { throw "Python was not found." }

$need = @()

function Test-PythonModule($moduleName) {
    & python -c "import importlib.util,sys; sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)" $moduleName 2>$null
    return ($LASTEXITCODE -eq 0)
}

if (!(Test-PythonModule "PyInstaller")) { $need += "pyinstaller" }
if (!(Test-PythonModule "yt_dlp")) { $need += "yt-dlp" }
if (!(Test-PythonModule "ytmusicapi")) { $need += "ytmusicapi" }
if (!(Test-PythonModule "tkinterdnd2")) { $need += "tkinterdnd2" }
if (!(Test-PythonModule "customtkinter")) { $need += "customtkinter" }
if (!(Test-PythonModule "PIL")) { $need += "Pillow" }
if (!(Test-PythonModule "mutagen")) { $need += "mutagen" }

if ($need.Count -gt 0) {
    Write-Host "Installing missing packages: $($need -join ', ')"
    & python -m pip install @need
} else {
    Write-Host "Python build packages already installed - skipping pip."
}
if ($LASTEXITCODE -ne 0) { throw "Python package installation failed." }

if (Test-Path ".\dist") { Remove-Item ".\dist" -Recurse -Force }
if (Test-Path ".\Release") { Remove-Item ".\Release" -Recurse -Force }
New-Item ".\Release" -ItemType Directory | Out-Null

python -m PyInstaller --noconfirm --windowed --onefile `
  --name "ATRAC_Audio_Converter_v31_38_Unified" `
  --icon "ATRAC_v30.ico" `
  --add-binary "ffmpeg.exe;." `
  --add-binary "ffprobe.exe;." `
  --add-binary "ffplay.exe;." `
  --add-binary "atracdenc.exe;." `
  --add-binary "yt-dlp.exe;." `
  --add-binary "deno.exe;." `
  --hidden-import tkinterdnd2 `
  --hidden-import customtkinter `
  --hidden-import ytmusicapi `
  --collect-all tkinterdnd2 `
  --collect-all customtkinter `
  --collect-all mutagen `
  --collect-all ytmusicapi `
  "ATRAC_UI_v31_38_UNIFIED.pyw"

if ($LASTEXITCODE -ne 0) { throw "EXE build failed." }

Copy-Item ".\dist\ATRAC_Audio_Converter_v31_38_Unified.exe" ".\Release\ATRAC_Audio_Converter_v31_38_Unified.exe" -Force

Write-Host ""
Write-Host "=========================================="
Write-Host "DONE!"
Write-Host "Release\ATRAC_Audio_Converter_v31_38_Unified.exe"
Write-Host "=========================================="
