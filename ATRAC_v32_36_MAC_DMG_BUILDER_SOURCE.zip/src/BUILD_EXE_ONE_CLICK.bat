@echo off
cd /d "%~dp0"
echo ATRAC Audio Video Converter - One Click Builder
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0AUTO_BUILD_V30.ps1"
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Please send a screenshot of this window.
  pause
  exit /b 1
)
echo.
echo Finished. Open the Release folder.
pause