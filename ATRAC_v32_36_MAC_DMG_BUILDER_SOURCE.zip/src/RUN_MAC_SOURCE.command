#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ -d /opt/homebrew/bin ]]; then export PATH="/opt/homebrew/bin:$PATH"; fi
if [[ -d /usr/local/bin ]]; then export PATH="/usr/local/bin:$PATH"; fi
if [[ ! -d .venv-mac ]]; then
  echo "先に BUILD_MAC.command を実行してください。"
  read -r -p "Press Enter to close..." _
  exit 1
fi
source .venv-mac/bin/activate
python ATRAC_UI_v31_38_UNIFIED.pyw
